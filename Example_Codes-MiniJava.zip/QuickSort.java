class QuickSort {
    public static void main(String[] a) {
        cmdo
    }
}

// This class contains the array of integers and
// methods to initialize, print and sort the array
// using Quicksort
class QS {

    int[] number;
    int size;

    // Invoke the Initialization, Sort and Printing
    // Methods
    public int Start(int sz) {
        int aux01;
        cmdo
    }

    // Sort array of integers using Quicksort method
    public int Sort(int left, int right) {
        int v;
        int i;
        int j;
        int nt;
        int t;
        boolean cont01;
        boolean cont02;
        int aux03;
       cmdo
    }

    // Print array of integers
    public int Print() {
        int j;
    cmdo
    }

    // Initialize array of integers
    public int Init(int sz) {
      cmdo
    }

}
