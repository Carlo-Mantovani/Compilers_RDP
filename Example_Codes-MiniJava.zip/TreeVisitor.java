// The classes are basically the same as the BinaryTree 
// file except the visitor classes and the accept method
// in the Tree class

class TreeVisitor {
    public static void main(String[] a) {
       cmdo
    }
}

class TV {

    public int Start() {
        Tree root;
        boolean ntb;
        int nti;
        MyVisitor v;

      cmdo
    }

}

class Tree {
    Tree left;
    Tree right;
    int key;
    boolean has_left;
    boolean has_right;
    Tree my_null;

    

    public boolean Init(int v_key) {
       cmdo
    }

    public boolean SetRight(Tree rn) {
        cmdo
    }

    public boolean SetLeft(Tree ln) {
        cmdo
    }

    public Tree GetRight() {
        cmdo
    }

    public Tree GetLeft() {
      cmdo
    }

    public int GetKey() {
        cmdo
    }

    public boolean SetKey(int v_key) {
       cmdo
    }

    public boolean GetHas_Right() {
        cmdo
    }

    public boolean GetHas_Left() {
        cmdo
    }

    public boolean SetHas_Left(boolean val) {
        cmdo
    }

    public boolean SetHas_Right(boolean val) {
        cmdo
    }

    public boolean Compare(int num1, int num2) {
        boolean ntb;
        int nti;

        cmdo
    }

    public boolean Insert(int v_key) {
        Tree new_node;
        boolean ntb;
        Tree current_node;
        boolean cont;
        int key_aux;

       cmdo
    }

    public boolean Delete(int v_key) {
        Tree current_node;
        Tree parent_node;
        boolean cont;
        boolean found;
        boolean ntb;
        boolean is_root;
        int key_aux;

        cmdo
    }

    public boolean Remove(Tree p_node, Tree c_node) {
        boolean ntb;
        int auxkey1;
        int auxkey2;

        cmdo
    }

    public boolean RemoveRight(Tree p_node, Tree c_node) {
        boolean ntb;
       cmdo
    }

    public boolean RemoveLeft(Tree p_node, Tree c_node) {
        boolean ntb;
        cmdo
    }

    public int Search(int v_key) {
        Tree current_node;
        int ifound;
        boolean cont;
        int key_aux;

        cmdo
    }

    public boolean Print() {
        boolean ntb;
        Tree current_node;

        cmdo
    }

    public boolean RecPrint(Tree node) {
        boolean ntb;

        cmdo
    }

    public int accept(Visitor v) {
        int nti;

        cmdo
    }

}

class Visitor {
    Tree l;
    Tree r;

    public int visit(Tree n) {
        int nti;
cmdo
    }

}

class MyVisitor extends Visitor {

    public int visit(Tree n) {
        int nti;

        cmdo
    }

}
