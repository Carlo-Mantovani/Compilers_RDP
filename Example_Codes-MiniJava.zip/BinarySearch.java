class BinarySearch{
    public static void main(String[] a){
	cmdo
    }
}
// This class contains an array of integers and
// methods to initialize, print and search the array
// using Binary Search

class BS{
    int[] number ;
    int size ;

    // Invoke methods to initialize, print and search
    // for elements on the array
    public int Start(int sz){
	int aux01 ;
	int aux02 ;
	cmdo
    }


    // Search for a specific value (num) using
    // binary search
    public boolean Search(int num){
	boolean bs01 ;
	int right ;
	int left ;
	boolean var_cont ;
	int medium ;
	int aux01 ;
	int nt ;

	cmdo
    }

    // This method computes and returns the
    // integer division of a number (num) by 2
    public int Div(int num){
	int count01 ;
	int count02 ;
	int aux03 ;

	cmdo
    }

    
    // This method compares two integers and
    // returns true if they are equal and false
    // otherwise
    public boolean Compare(int num1 , int num2){
	boolean retval ;
	int aux02 ;

	cmdo
    }

    // Print the integer array
    public int Print(){
	int j ;

	cmdo
    }
    

    // Initialize the integer array
    public int Init(int sz){
	int j ;
	int k ;
	int aux02 ;
	int aux01 ;

	cmdo
    }

}