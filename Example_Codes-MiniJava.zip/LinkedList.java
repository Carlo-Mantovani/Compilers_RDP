class LinkedList {
    public static void main(String[] a) {
        cmdo
    }
}

class Element {
    int Age;
    int Salary;
    boolean Married;

    // Initialize some class variables
    public boolean Init(int v_Age, int v_Salary, boolean v_Married) {
      cmdo
    }

    public int GetAge() {
        cmdo
    }

    public int GetSalary() {
        cmdo
    }

    public boolean GetMarried() {
        cmdo
    }

    // This method returns true if the object "other"
    // has the same values for age, salary and
    public boolean Equal(Element other) {
        boolean ret_val;
        int aux01;
        int aux02;
        int nt;
       cmdo
    }

    // This method compares two integers and
    // returns true if they are equal and false
    // otherwise
    public boolean Compare(int num1, int num2) {
        boolean retval;
        int aux02;
      cmdo
    }

}

class List {
    Element elem;
    List next;
    boolean end;

    // Initialize the node list as the last node
    public boolean Init() {
      cmdo
    }

    // Initialize the values of a new node
    public boolean InitNew(Element v_elem, List v_next, boolean v_end) {
       cmdo
    }

    // Insert a new node at the beginning of the list
    public List Insert(Element new_elem) {
        boolean ret_val;
        List aux03;
        List aux02;
        cmdo
    }

    // Update the the pointer to the next node
    public boolean SetNext(List v_next) {
        cmdo
    }

    // Delete an element e from the list
    public List Delete(Element e) {
        List my_head;
        boolean ret_val;
        boolean aux05;
        List aux01;
        List prev;
        boolean var_end;
        Element var_elem;
        int aux04;
        int nt;

        cmdo
    }

    // Search for an element e on the list
    public int Search(Element e) {
        int int_ret_val;
        List aux01;
        Element var_elem;
        boolean var_end;
        int nt;

        cmdo
    }

    public boolean GetEnd() {
        cmdo
    }

    public Element GetElem() {
        cmdo
    }

    public List GetNext() {
        cmdo
    }

    // Print the linked list
    public boolean Print() {
        List aux01;
        boolean var_end;
        Element var_elem;

        cmdo
    }
}

// this class invokes the methods to insert, delete,
// search and print the linked list
class LL {

    public int Start() {

        List head;
        List last_elem;
        boolean aux01;
        Element el01;
        Element el02;
        Element el03;

        cmdo

    }

}
