class BinaryTree {
    public static void main(String[] a) {
        cmdo
    }
}

// This class invokes the methods to create a tree,
// insert, delete and serach for elements on it
class BT {

    public int Start() {
        Tree root;
        boolean ntb;
        int nti;
        cmdo
    }

}

class Tree {
    Tree left;
    Tree right;
    int key;
    boolean has_left;
    boolean has_right;
    Tree my_null;

    // Initialize a node with a key value and no children
    public boolean Init(int v_key) {
        cmdo
    }

    // Update the right child with rn
    public boolean SetRight(Tree rn) {
        cmdo
    }

    // Update the left child with ln
    public boolean SetLeft(Tree ln) {
       cmdo
    }

    public Tree GetRight() {
        cmdo
    }

    public Tree GetLeft() {
        cmdo
    }

    public int GetKey() {
        cmdo
    }

    public boolean SetKey(int v_key) {
        cmdo
    }

    public boolean GetHas_Right() {
        cmdo
    }

    public boolean GetHas_Left() {
        cmdo
    }

    public boolean SetHas_Left(boolean val) {
        cmdo
    }

    public boolean SetHas_Right(boolean val) {
        cmdo
    }

    // This method compares two integers and
    // returns true if they are equal and false
    // otherwise
    public boolean Compare(int num1, int num2) {
        boolean ntb;
        int nti;

       cmdo
    }

    // Insert a new element in the tree
    public boolean Insert(int v_key) {
        Tree new_node;
        boolean ntb;
        boolean cont;
        int key_aux;
        Tree current_node;

       cmdo
    }

    // Delete an element from the tree
    public boolean Delete(int v_key) {
        Tree current_node;
        Tree parent_node;
        boolean cont;
        boolean found;
        boolean is_root;
        int key_aux;
        boolean ntb;

        cmdo
    }

    // Check if the element to be removed will use the
    // righ or left subtree if one exists
    public boolean Remove(Tree p_node, Tree c_node) {
        boolean ntb;
        int auxkey1;
        int auxkey2;

       cmdo
    }

    // Copy the child key to the parent until a leaf is
    // found and remove the leaf. This is done with the
    // right subtree
    public boolean RemoveRight(Tree p_node, Tree c_node) {
        boolean ntb;

        cmdo
    }

    // Copy the child key to the parent until a leaf is
    // found and remove the leaf. This is done with the
    // left subtree
    public boolean RemoveLeft(Tree p_node, Tree c_node) {
        boolean ntb;

       cmdo
    }

    // Search for an elemnt in the tree
    public int Search(int v_key) {
        boolean cont;
        int ifound;
        Tree current_node;
        int key_aux;

        cmdo
    }

    // Invoke the method to really print the tree elements
    public boolean Print() {
        Tree current_node;
        boolean ntb;

       cmdo
    }

    // Print the elements of the tree
    public boolean RecPrint(Tree node) {
        boolean ntb;

        cmdo
    }

}
