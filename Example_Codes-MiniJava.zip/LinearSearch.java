class LinearSearch {
    public static void main(String[] a) {
        cmdo
    }
}

// This class contains an array of integers and
// methods to initialize, print and search the array
// using Linear Search
class LS {
    int[] number;
    int size;

    // Invoke methods to initialize, print and search
    // for elements on the array
    public int Start(int sz) {
        int aux01;
        int aux02;

       cmdo
    }

    // Print array of integers
    public int Print() {
        int j;

        cmdo
    }

    // Search for a specific value (num) using
    // linear search
    public int Search(int num) {
        int j;
        boolean ls01;
        int ifound;
        int aux01;
        int aux02;
        int nt;

        cmdo
    }

    // initialize array of integers with some
    // some sequence
    public int Init(int sz) {
        int j;
        int k;
        int aux01;
        int aux02;

       cmdo
    }

}
