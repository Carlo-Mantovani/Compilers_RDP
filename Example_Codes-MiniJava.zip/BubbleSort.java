class BubbleSort {
    public static void main(String[] a) {
        cmdo
    }
}

// This class contains the array of integers and
// methods to initialize, print and sort the array
// using Bublesort
class BBS {

    int[] number;
    int size;

    // Invoke the Initialization, Sort and Printing
    // Methods
    public int Start(int sz) {
        int aux01;
       cmdo
    }

    // Sort array of integers using Bublesort method
    public int Sort() {
        int nt;
        int i;
        int aux02;
        int aux04;
        int aux05;
        int aux06;
        int aux07;
        int j;
        int t;
       cmdo
    }

    // Printing method
    public int Print() {
        int j;
       cmdo
    }

    // Initialize array of integers
    public int Init(int sz) {
       cmdo
    }

}
