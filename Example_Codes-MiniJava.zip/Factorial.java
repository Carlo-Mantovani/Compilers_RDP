class Factorial{
    public static void main(String[] a){
	cmdo
    }
}

class Fac {

    public int ComputeFac(int num){
	int num_aux;
	cmdo
    }

}