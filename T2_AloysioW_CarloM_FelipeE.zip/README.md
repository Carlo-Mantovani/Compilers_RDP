# Authors
Aloysio Winter, Carlo Mantovani, Felipe Elsner

# Compile

## Linux
	make
## Windows
	java -jar jflex.jar mini_java.flex
	javac AsdrSample.java

# Run
	java AsdrSample Program.java
	
	
